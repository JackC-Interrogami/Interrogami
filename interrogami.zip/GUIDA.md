# Interrogami 2 — guida per metterla online e installarla sul telefono

Va bene per ogni classe, dalla 1ª elementare alla 5ª superiore: l'insegnante adatta il linguaggio e le domande alla classe scelta nelle Impostazioni.

## Cosa c'è nello zip

| File | A cosa serve |
|---|---|
| `index.html` | l'app vera e propria (tutto in un file) |
| `manifest.webmanifest` | dice al telefono nome, icona e colori dell'app |
| `sw.js` | fa funzionare l'app anche senza rete (tranne le domande, che passano da Gemini) |
| `icon-192.png`, `icon-512.png`, `icon-512-maskable.png` | le icone |
| `GUIDA.md` | questa guida |

Tutti i file devono stare **insieme nella stessa cartella** sul sito.

## Passo 1 — Metterla online gratis (GitHub Pages)

1. Vai su https://github.com e crea un account gratuito (basta un'email).
2. In alto a destra premi **+** → **New repository**.
   - Repository name: `interrogami`
   - Lascia **Public** (serve per avere il sito gratis)
   - Premi **Create repository**.
3. Nella pagina del repository premi **uploading an existing file** (oppure **Add file → Upload files**).
4. Trascina dentro **tutti i file** dello zip (non lo zip, i file scompattati) e premi **Commit changes** in basso.
5. Vai su **Settings** (la rotella in alto nel repository) → nel menu a sinistra **Pages**.
6. Sotto *Build and deployment* → *Source* scegli **Deploy from a branch**; sotto *Branch* scegli **main** e **/ (root)**, poi **Save**.
7. Aspetta un minuto e ricarica la pagina: in alto compare l'indirizzo del sito, del tipo
   `https://TUONOME.github.io/interrogami/`
   Aprilo: l'app è online.

Per aggiornare l'app in futuro basta ricaricare i file nuovi allo stesso modo (Add file → Upload files): sostituiscono i vecchi.

### Alternativa: Netlify

Se preferisci, su https://app.netlify.com (account gratuito) vai su **Sites → Add new site → Deploy manually** e trascina la cartella con i file. Ti dà un indirizzo tipo `nome-a-caso.netlify.app`, che puoi cambiare da *Site configuration → Change site name*.

## Passo 2 — Installarla sul telefono

**iPhone / iPad (Safari)**
1. Apri l'indirizzo del sito in Safari.
2. Premi il tasto **Condividi** (il quadrato con la freccia in su).
3. Scegli **Aggiungi alla schermata Home** → **Aggiungi**.
Compare l'icona di Interrogami come una vera app.

**Android (Chrome)**
1. Apri l'indirizzo in Chrome.
2. Menu **⋮** in alto a destra → **Installa app** (o *Aggiungi a schermata Home*).

**PC (Chrome o Edge)**: nella barra dell'indirizzo compare un'icona "Installa"; cliccala.

## Passo 3 — La chiave Gemini

1. Sul telefono, apri l'app → **Impostazioni**.
2. Scrivi il nome, scegli ragazza/ragazzo e la classe.
3. Crea la chiave gratuita su https://aistudio.google.com/apikey (serve un account Google), copiala e incollala in **Chiave API** → **Salva e controlla**.
La chiave resta salvata solo su quel telefono: va fatto una volta per ogni dispositivo.

**Sconsigliato ma possibile**: in `index.html` c'è la riga `var EMBEDDED_KEY = "";`. Se ci scrivi la chiave tra le virgolette, l'app non la chiede più. Ma il sito è pubblico: chiunque apra il codice della pagina può leggerla e usarla con la tua quota gratuita. Meglio inserirla nelle Impostazioni.

## Come si usa

- **Materie** (prima schermata): una scheda per ogni materia con la fiamma dei giorni di fila (resta accesa se fai almeno un'interrogazione al giorno in quella materia), il voto in decimi e l'ultimo argomento ripassato. Toccando una materia entri nella sua pagina: appunti salvati, elenco dei ripassi fatti (data, argomento e voto), e **Da ripassare** con le domande sbagliate negli ultimi 30 giorni e il tasto **Ripassa gli errori**, che prepara un quiz nuovo proprio su quei punti.
- **Tipo di materia** (si sceglie solo quando crei o rinomini una materia): Normale, Inglese, Francese, Spagnolo, Tedesco, Latino, Greco, Matematica, Fisica, Chimica. Per i tipi diversi da «Normale» dentro la materia compare una scheda di strumenti, adattata alla classe:
  - *Lingue*: traduttore (italiano ↔ lingua), spiegazione «come il dizionario» (significati, pronuncia, forme irregolari, espressioni, falsi amici, anche nel contesto della frase in cui hai trovato la parola) e correzione di un testo scritto nella lingua.
  - *Latino e Greco*: aiuto versione frase per frase (verbo, soggetto, costrutti, analisi delle parole, traduzione letterale e in buon italiano, oppure «solo aiuti» senza traduzione), analisi di una parola con paradigma e tabelle, ripasso di grammatica.
  - *Matematica, Fisica, Chimica*: aiuto esercizio passo passo (o «solo il metodo» senza risultato), formulario sull'argomento, correzione dello svolgimento fatto dallo studente, esercizi simili con soluzioni. Le formule vengono mostrate in notazione matematica, le reazioni chimiche bilanciate con pedici.
  Sotto gli strumenti c'è la scheda **Siti utili per questa materia** con i portali famosi (Photomath, WolframAlpha, GeoGebra, WordReference, Reverso, dizionari Olivetti di latino e greco, Ptable, PhET, Treccani...) che si aprono fuori dall'app. L'insegnante IA dichiara quanto è sicura di ogni risposta e, per matematica, fisica e chimica, il risultato viene ricontrollato con una seconda richiesta indipendente: se l'IA è poco sicura o il ricontrollo non coincide, compare un banner «Risultato probabilmente non accurato» con i siti consigliati per quella materia.
  In tutti i casi si può scrivere, dettare o fotografare l'esercizio/la versione, e dopo la risposta c'è la casella «Non hai capito qualcosa? Chiedi qui» per continuare la spiegazione. Anche le interrogazioni della sezione Studia si adattano al tipo (vocaboli e grammatica per le lingue, declinazioni e paradigmi per latino e greco, esercizi brevi e formule per le materie scientifiche).
- **Appunti**: dentro la materia premi «+ Nuovi appunti» e salvi testo scritto o dettato, PDF, Word (.docx), foto del libro o del quaderno (anche scattate al momento), scansioni. Restano salvati sul telefono.
- **Studia**: scegli materia e appunti (anche più di uno insieme), il tipo di esercizio e quante domande:
  - *Scelta multipla*, *Vero o falso*, *Completa la frase*: si risponde con un tocco.
  - *Risposta aperta*: scrive (o detta) con parole sue e l'insegnante corregge.
  - *Flashcard*: ripasso veloce, dice lei se la sapeva o no.
  - *Ripeti la lezione*: racconta tutto come alla cattedra; l'insegnante dà un voto e dice cosa ha detto bene, cosa ha sbagliato e cosa ha dimenticato, con le frasi degli appunti.
- **Registro**: un voto in decimi per ogni interrogazione (10 × risposte giuste / totali; «Ripeti la lezione» usa il suo voto), con la nota dell'insegnante su cosa è andato bene e cosa è da rivedere e, aprendo «Dettaglio delle risposte», l'elenco delle domande giuste e sbagliate.
- **Impostazioni → Scarica backup**: salva un file con materie, appunti e registro. Con **Carica backup** li riporti su un altro telefono o dopo aver cambiato browser. **Azzera tutto** riporta l'app come appena installata su quel dispositivo (cancella anche nome e chiave): utile se la provi tu prima di passarla a qualcun altro sullo stesso telefono.

## Cose da sapere

- I dati (appunti, storico) stanno **solo nel browser del telefono**: se si cancellano i dati di Safari/Chrome spariscono. Fai un backup ogni tanto.
- La dettatura con il microfono funziona su Safari (iPhone) e Chrome; se il tasto 🎤 non compare, quel browser non la supporta.
- Le domande arrivano da Gemini con il piano gratuito: se compare "le richieste gratuite di questo minuto sono finite", basta aspettare un po'.
