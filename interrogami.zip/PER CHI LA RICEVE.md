# Interrogami — come iniziare (da mandare insieme al link)

Ciao! Questo è il link di Interrogami, un'app per farti interrogare sui tuoi appunti:

**[incolla qui l'indirizzo del sito]**

Tutto quello che scrivi (appunti, voti, chiave) resta **solo sul tuo telefono**: nessun altro lo vede, nemmeno chi ti ha mandato il link.

## 1. Mettila sul telefono come un'app
- **iPhone/iPad**: apri il link in Safari → tasto **Condividi** (quadrato con la freccia) → **Aggiungi alla schermata Home**.
- **Android**: apri il link in Chrome → menu **⋮** → **Installa app** (o *Aggiungi a schermata Home*).

## 2. La tua chiave Gemini (gratis, ci vuole un minuto)
L'insegnante che fa le domande è l'intelligenza artificiale di Google (Gemini) e serve una chiave personale, gratuita.
1. Vai su https://aistudio.google.com/apikey ed entra con il tuo account Google.
2. Premi **Create API key** (o *Crea chiave API*) e copia la chiave (una lunga riga di lettere e numeri).
3. Nell'app vai in **Impostazioni**, scrivi il tuo nome e la classe, incolla la chiave in **Chiave API** e premi **Salva e controlla**.
La chiave resta salvata sul tuo telefono: lo fai una volta sola. Non condividerla con nessuno.

## 3. Materie e appunti
- Nella prima schermata premi **+ Nuova materia**, scrivi il nome e scegli il tipo (Normale, oppure Inglese, Latino, Matematica... che danno strumenti in più).
- Dentro la materia premi **+ Nuovi appunti**: scrivi o detta il riassunto, oppure fotografa le pagine del libro o del quaderno, o allega PDF e Word.

## 4. Fatti interrogare
Vai su **Studia**, scegli materia, appunti e tipo di esercizio (scelta multipla, vero/falso, completa la frase, risposta aperta, flashcard, ripeti la lezione) e premi **Inizia**. In **Registro** trovi un voto per ogni interrogazione con le note dell'insegnante; nella prima schermata la fiamma dei giorni di fila per ogni materia.

## Se qualcosa non va
- "Le richieste gratuite di questo minuto sono finite": aspetta un po' e riprova, la versione gratuita di Gemini ha un limite.
- Se cambi telefono o cancelli i dati del browser gli appunti spariscono: in **Impostazioni → Scarica backup** salvi tutto in un file, e con **Carica backup** lo rimetti.
